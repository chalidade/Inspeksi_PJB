			<?php include "header.php"; ?>

			<?php
			$jabatan = $_SESSION['jabatan'];
			if ($jabatan == "Admin") {
			?>
			<!-- Start service Area -->
			<section class="service-area section-gap" id="facilities" style="padding-top:40px;">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-8 pb-10 header-text">
							<h3>HSE ACCOUNT</h3>
							<p> What will you do ?	</p>
						</div>
					</div>
					<div class="row" style="padding:10px">
						<div class="col-6">
						  <div class="content">
						    <a href="menu_job_observation.php">
						  		 <img class="content-image img-fluid d-block mx-auto" style="width:50%;" src="img/checklist.png" alt="">
						      <div class="content-details fadeIn-bottom">
						        <!-- <h3 class="content-title" style="font-size:12px;">Job Safety Observation</h3> -->
						      </div>
						    </a>
						  </div>
							<h3 class="content-title" style="font-size:12px;color:#000; text-align:center;margin-top:10px;">Job Safety Observation</h3>
						</div>
						<div class="col-6">
						  <div class="content">
						    <a href="menu_liveaudit.php">
						  		 <img class="content-image img-fluid d-block mx-auto" style="width:50%;" src="img/clipboard.png" alt="">
						      <div class="content-details fadeIn-bottom">
						        <!-- <h3 class="content-title"  style="font-size:12px;">Live Audit </h3> -->
						      </div>
						    </a>
						  </div>
							<h3 class="content-title" style="font-size:12px;color:#000; text-align:center;margin-top:10px;">Live Audit</h3>
						</div>
					</div>
					<div class="row" style="margin-top:50px; padding:10px">
						<div class="col-6">
						  <div class="content">
						    <a href="menu_nearmiss.php">
						  		 <img class="content-image img-fluid d-block mx-auto" style="width:50%;" src="img/notepad.png" alt="">
						      <div class="content-details fadeIn-bottom">
						        <!-- <h3 class="content-title" style="font-size:12px;">Nearmiss</h3> -->
						      </div>
						    </a>
						  </div>
							<h3 class="content-title" style="font-size:12px;color:#000; text-align:center;margin-top:10px;">Nearmiss</h3>
						</div>
						<div class="col-6">
						  <div class="content">
						    <a href="menu-laporan.php">
						  		 <img class="content-image img-fluid d-block mx-auto" style="width:50%;" src="img/schedule.png" alt="">
						      <div class="content-details fadeIn-bottom">
						        <!-- <h3 class="content-title"  style="font-size:12px;">Logout </h3> -->
						      </div>
						    </a>
						  </div>
							<h3 class="content-title" style="font-size:12px;color:#000; text-align:center;margin-top:10px;">Laporan</h3>
						</div>
					</div>
					<div class="row" style="margin-top:50px; padding:10px">
						<div class="col-6">
							<div class="content">
								<a href="account.php">
									 <img class="content-image img-fluid d-block mx-auto" style="width:50%;" src="img/videocall.png" alt="">
									<div class="content-details fadeIn-bottom">
										<!-- <h3 class="content-title"  style="font-size:12px;">Logout </h3> -->
									</div>
								</a>
							</div>
							<h3 class="content-title" style="font-size:12px;color:#000; text-align:center;margin-top:10px;">User</h3>
						</div>
						<div class="col-6">
						  <div class="content">
						    <a href="notifikasi.php">
						  		 <img class="content-image img-fluid d-block mx-auto" style="width:50%;" src="img/exclamation-mark.png" alt="">
						      <div class="content-details fadeIn-bottom">
						        <!-- <h3 class="content-title"  style="font-size:12px;">Logout </h3> -->
						      </div>
						    </a>
						  </div>
							<h3 class="content-title" style="font-size:12px;color:#000; text-align:center;margin-top:10px;">Notifikasi</h3>
						</div>
					</div>
				<div class="row" style="margin-top:50px; padding:10px">
					<div class="col-6">
						<div class="content">
							<a href="../index.php">
								 <img class="content-image img-fluid d-block mx-auto" style="width:50%;" src="img/wall-clock.png" alt="">
								<div class="content-details fadeIn-bottom">
									<!-- <h3 class="content-title"  style="font-size:12px;">Logout </h3> -->
								</div>
							</a>
						</div>
						<h3 class="content-title" style="font-size:12px;color:#000; text-align:center;margin-top:10px;">Logout</h3>
					</div>
				</div>
			</section>
			<!-- End service Area -->
		<?php } else { ?>
			<!-- Start service Area -->
			<section class="service-area section-gap" id="facilities" style="padding-top:40px;">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-8 pb-10 header-text">
							<h3>USER ACCOUNT</h3>
							<p> What will you do ?	</p>
						</div>
					</div>
					<div class="row" style="margin-top:50px; padding:10px">
						<div class="col-6">
						  <div class="content">
						    <a href="menu-laporan.php">
						  		 <img class="content-image img-fluid d-block mx-auto" style="width:50%;" src="img/schedule.png" alt="">
						      <div class="content-details fadeIn-bottom">
						        <!-- <h3 class="content-title"  style="font-size:12px;">Logout </h3> -->
						      </div>
						    </a>
						  </div>
							<h3 class="content-title" style="font-size:12px;color:#000; text-align:center;margin-top:10px;">Laporan</h3>
						</div>
						<div class="col-6">
							<div class="content">
								<a href="../index.php">
									 <img class="content-image img-fluid d-block mx-auto" style="width:50%;" src="img/wall-clock.png" alt="">
									<div class="content-details fadeIn-bottom">
										<!-- <h3 class="content-title"  style="font-size:12px;">Logout </h3> -->
									</div>
								</a>
							</div>
							<h3 class="content-title" style="font-size:12px;color:#000; text-align:center;margin-top:10px;">Logout</h3>
						</div>
					</div>
			</section>
			<!-- End service Area -->
		<?php } ?>
		<?php include "footer.php"; ?>
